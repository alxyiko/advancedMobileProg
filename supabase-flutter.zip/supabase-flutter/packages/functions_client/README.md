# `functions-dart`

## Docs

The docs can be found on the official Supabase website.

- [Dart reference](https://supabase.com/docs/reference/dart/functions-invoke)
- [Edge Functions guide](https://supabase.com/docs/guides/functions)

## License

This repo is licensed under MIT.

## Credits

- https://github.com/supabase/functions-js - ported from supabase/functions-js fork
