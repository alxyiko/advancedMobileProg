import 'package:functions_client/src/version.dart';

class Constants {
  static const defaultHeaders = {
    'X-Client-Info': 'functions-dart/$version',
  };
}
