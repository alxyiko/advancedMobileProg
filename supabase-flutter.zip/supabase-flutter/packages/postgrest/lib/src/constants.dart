import 'package:postgrest/src/version.dart';

const defaultHeaders = {'X-Client-Info': 'postgrest-dart/$version'};
