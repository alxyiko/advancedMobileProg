import 'package:web_socket_channel/web_socket_channel.dart';

WebSocketChannel createWebSocketClient(
  String url,
  Map<String, String> headers,
) {
  throw UnimplementedError(
    'Websocket Client not implemented for this platform',
  );
}
