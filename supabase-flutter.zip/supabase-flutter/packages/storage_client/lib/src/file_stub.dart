// coverage:ignore-file
/// A stub for the `dart:io` [File] class.
typedef File = dynamic;
