#### Examples

- Flutter user management: https://github.com/supabase/supabase/tree/master/examples/flutter-user-management
- Extended flutter user management with web support, github login, recovery password flow
  - https://github.com/phamhieu/supabase-flutter-demo
- Spot, open source geo based video sharing social app created with Flutter
  - https://github.com/dshukertjr/spot
- Notes app: https://github.com/bigblackclock/supabase_notes
