//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import app_links

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  AppLinksMacosPlugin.register(with: registry.registrar(forPlugin: "AppLinksMacosPlugin"))
}
