package com.example.viewmenu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
